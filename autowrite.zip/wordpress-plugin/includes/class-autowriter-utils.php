<?php

class AutoWriter_Utils {

    public static function log($message, $level = 'info', $context = []) {
        // Implementation for generic logging if needed
    }

    public static function sanitize_payload($payload) {
        // Implementation for extra sanitization
        return $payload;
    }
}
